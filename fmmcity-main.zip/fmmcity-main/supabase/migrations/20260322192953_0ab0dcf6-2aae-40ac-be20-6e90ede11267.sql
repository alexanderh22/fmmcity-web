CREATE TABLE public.chat_leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  conversation_context TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.chat_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow anonymous inserts" ON public.chat_leads
  FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY "Allow service role select" ON public.chat_leads
  FOR SELECT TO service_role USING (true);