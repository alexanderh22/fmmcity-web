import heroBg from "@/assets/hero-bg.jpg";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import HowItWorks from "@/components/HowItWorks";
import Benefits from "@/components/Benefits";
import ReadMore from "@/components/ReadMore";
import BookingForm from "@/components/BookingForm";
import Footer from "@/components/Footer";
import ChatWidget from "@/components/ChatWidget";

const Index = () => (
  <div className="relative min-h-screen">
    {/* Fixed full-page background — GPU-promoted for smooth scroll */}
    <div className="fixed inset-0 -z-10 will-change-transform" style={{ transform: 'translateZ(0)' }}>
      <img src={heroBg} alt="" className="w-full h-full object-cover" loading="eager" decoding="async" />
      <div className="absolute inset-0 bg-foreground/60" />
    </div>

    <Navbar />
    <Hero />
    <HowItWorks />
    <Benefits />
    <ReadMore />
    <BookingForm />
    <Footer />
    <ChatWidget />
  </div>
);

export default Index;
