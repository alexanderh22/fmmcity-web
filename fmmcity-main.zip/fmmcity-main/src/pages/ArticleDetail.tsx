import { ArrowLeft } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import heroBg from "@/assets/hero-bg.jpg";
import { articles } from "@/data/articles";
import Navbar from "@/components/Navbar";
import ChatWidget from "@/components/ChatWidget";

const ArticleDetail = () => {
  const navigate = useNavigate();
  const { slug } = useParams();
  const article = articles.find((a) => a.slug === slug);

  if (!article) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-serif text-foreground mb-4">Artikeln hittades inte</h1>
          <button onClick={() => navigate("/artiklar")} className="text-primary hover:underline">
            Tillbaka till artiklar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen">
      <div className="fixed inset-0 -z-10">
        <img src={heroBg} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-foreground/70" />
      </div>

      <Navbar />

      {/* Back button */}
      <button
        onClick={() => navigate("/artiklar")}
        className="fixed top-24 left-6 z-40 bg-card/80 backdrop-blur-md border border-border rounded-full p-3 text-muted-foreground hover:text-foreground hover:bg-card transition-all shadow-soft"
      >
        <ArrowLeft className="w-5 h-5" />
      </button>

      <main className="pt-24 pb-24">
        <div className="container mx-auto px-4">
          <article className="max-w-3xl mx-auto bg-card/95 backdrop-blur-sm rounded-3xl p-8 md:p-14 shadow-card border border-white/10">
            <div className="flex items-center gap-3 text-xs text-muted-foreground mb-4">
              <span>{article.date}</span>
              <span className="w-1 h-1 rounded-full bg-muted-foreground" />
              <span>{article.readTime} läsning</span>
            </div>

            <h1 className="text-2xl md:text-3xl font-serif text-foreground mb-8 leading-tight">
              {article.title}
            </h1>

            <div className="prose-article space-y-4 text-sm leading-relaxed [&>p]:text-muted-foreground [&>h2]:text-xl [&>h2]:font-serif [&>h2]:text-foreground [&>h2]:mt-8 [&>h2]:mb-3 [&>ul]:space-y-2 [&>ul]:text-muted-foreground [&>ul]:list-disc [&>ul]:pl-5 [&_strong]:text-foreground">
              {article.content}
            </div>

            {/* Source */}
            <div className="bg-background/50 rounded-xl p-5 mt-10 border border-border">
              <p className="text-xs text-muted-foreground mb-1">Källa & fördjupning:</p>
              <a
                href={article.source.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-primary hover:underline font-medium"
              >
                {article.source.name} ↗
              </a>
            </div>

            <div className="border-t border-border pt-8 mt-8 flex flex-col sm:flex-row gap-4 items-center justify-between">
              <button
                onClick={() => navigate("/artiklar")}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Fler artiklar
              </button>
              <button
                onClick={() => navigate("/")}
                className="hero-gradient text-primary-foreground font-semibold px-8 py-3 rounded-lg shadow-soft hover:opacity-90 transition-opacity"
              >
                Kontakta oss →
              </button>
            </div>
          </article>
        </div>
      </main>
      <ChatWidget />
    </div>
  );
};

export default ArticleDetail;
