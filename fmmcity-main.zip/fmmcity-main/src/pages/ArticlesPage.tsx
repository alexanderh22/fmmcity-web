import { useNavigate } from "react-router-dom";
import heroBg from "@/assets/hero-bg.jpg";
import { articles } from "@/data/articles";
import Navbar from "@/components/Navbar";
import ChatWidget from "@/components/ChatWidget";

const ArticlesPage = () => {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen">
      <div className="fixed inset-0 -z-10">
        <img src={heroBg} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-foreground/70" />
      </div>

      <Navbar />

      <main className="pt-24 pb-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <p className="text-sm font-semibold tracking-widest text-primary uppercase mb-3">Kunskap</p>
              <h1 className="text-3xl md:text-4xl font-serif text-white mb-4">
                Läs mer om <span className="text-gradient-light">Meta-annonsering</span>
              </h1>
              <p className="text-white/70">
                Fördjupa dig i hur digital annonsering via Meta skapar konkreta resultat för fastighetsmäklare.
              </p>
            </div>

            <div className="space-y-6">
              {articles.map((article) => (
                <button
                  key={article.slug}
                  onClick={() => navigate(`/artiklar/${article.slug}`)}
                  className="w-full text-left bg-card/95 backdrop-blur-sm rounded-2xl p-8 shadow-card border border-white/10 hover:shadow-soft hover:scale-[1.01] transition-all group"
                >
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                    <span>{article.date}</span>
                    <span className="w-1 h-1 rounded-full bg-muted-foreground" />
                    <span>{article.readTime} läsning</span>
                  </div>
                  <h2 className="font-serif text-xl text-foreground mb-3 group-hover:text-primary transition-colors">
                    {article.title}
                  </h2>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {article.summary}
                  </p>
                  <span className="inline-block mt-4 text-sm font-semibold text-primary">
                    Läs artikeln →
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </main>
      <ChatWidget />
    </div>
  );
};

export default ArticlesPage;
