import logoSimple from "@/assets/logo-simple.png";
import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const scrollTo = (id: string) => {
    if (location.pathname !== "/") {
      navigate("/", { state: { scrollTo: id } });
    } else {
      document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    }
    setOpen(false);
  };

  const goToArticles = () => {
    navigate("/artiklar");
    setOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-card/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto flex items-center justify-between h-16 px-4">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => scrollTo("hero")}>
          <img src={logoSimple} alt="FMM City" className="h-8" />
          <span className="font-serif text-xl text-foreground">FMM City</span>
        </div>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-8">
          <button onClick={() => scrollTo("process")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">Vår process</button>
          <button onClick={() => scrollTo("benefits")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">Fördelar</button>
          <button onClick={goToArticles} className="text-sm text-muted-foreground hover:text-foreground transition-colors">Läs mer</button>
          <button onClick={() => scrollTo("book")} className="text-sm font-semibold hero-gradient text-primary-foreground px-5 py-2 rounded-lg hover:opacity-90 transition-opacity">
            Boka samtal
          </button>
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden text-foreground" onClick={() => setOpen(!open)}>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={open ? "M18 6 6 18M6 6l12 12" : "M4 12h16M4 6h16M4 18h16"} /></svg>
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-card border-b border-border px-4 pb-4 flex flex-col gap-3">
          <button onClick={() => scrollTo("process")} className="text-sm text-muted-foreground text-left">Vår process</button>
          <button onClick={() => scrollTo("benefits")} className="text-sm text-muted-foreground text-left">Fördelar</button>
          <button onClick={goToArticles} className="text-sm text-muted-foreground text-left">Läs mer</button>
          <button onClick={() => scrollTo("book")} className="text-sm font-semibold hero-gradient text-primary-foreground px-5 py-2 rounded-lg text-center">Boka samtal</button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
