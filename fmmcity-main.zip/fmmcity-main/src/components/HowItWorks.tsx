import { Megaphone, Users, PhoneCall, CalendarCheck } from "lucide-react";

const steps = [
  {
    icon: Megaphone,
    number: "01",
    title: "Digital annonsering via Meta",
    description:
      "Vi skapar och driver riktade annonskampanjer på Facebook och Instagram, skräddarsydda för ditt område. Resultatbaserad annonsering som stärker ditt varumärke lokalt.",
  },
  {
    icon: Users,
    number: "02",
    title: "40 till 90 leads per månad",
    description:
      "Kampanjerna genererar ett flöde av potentiella säljare som aktivt visar intresse. 40 till 90 leads beroende på område.",
  },
  {
    icon: PhoneCall,
    number: "03",
    title: "Våra innesäljare kvalificerar",
    description:
      "Vårt team av innesäljare ringer varje lead, ställer rätt frågor och kvalificerar dem utifrån dina specifika krav.",
  },
  {
    icon: CalendarCheck,
    number: "04",
    title: "10 till 20 bokade möten till dig",
    description:
      "Du får färdigbokade, seriösa möten direkt i kalendern. Exklusivt dina, inga delade leads. Bara kvalificerade säljare redo att träffa dig.",
  },
];

const HowItWorks = () => (
  <section id="process" className="py-24">
    <div className="container mx-auto px-4">
      <div className="max-w-4xl mx-auto bg-card rounded-3xl p-10 md:p-14 shadow-card border border-white/10">
        <div className="text-center mb-16">
          <p className="text-sm font-semibold tracking-widest text-primary uppercase mb-3">Vår process</p>
          <h2 className="text-3xl md:text-4xl font-serif text-foreground mb-4">
            Från annons till bokat möte
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Vi hanterar hela kedjan — från digital annonsering till kvalificering — så du kan fokusera på det du gör bäst: att slutföra affärer.
          </p>
        </div>

        <div className="space-y-0">
          {steps.map((step, i) => (
            <div key={i} className="relative flex gap-6 group">
              {i < steps.length - 1 && (
                <div className="absolute left-8 top-20 bottom-0 w-px bg-border" />
              )}
              
              <div className="flex-shrink-0 w-16 h-16 rounded-2xl hero-gradient flex items-center justify-center shadow-soft relative z-10 group-hover:scale-105 transition-transform">
                <step.icon className="w-7 h-7 text-primary-foreground" />
              </div>
              
              <div className="pb-12">
                <span className="text-xs font-bold text-primary tracking-wider">{step.number}</span>
                <h3 className="font-serif text-xl text-foreground mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed max-w-lg">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </section>
);

export default HowItWorks;
