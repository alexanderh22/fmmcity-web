import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const sections = [
  {
    id: "why-meta",
    title: "Varför annonserar vi via Meta?",
    content: (
      <>
        <p className="mb-3">
          Meta (Facebook och Instagram) är den plattform där flest potentiella bostadssäljare är aktiva dagligen. Till skillnad från sökmotorannonsering, där användaren redan har ett etablerat behov, når Meta-annonsering personer <strong>innan</strong> de har valt mäklare. Det ger dig möjligheten att positionera dig som det naturliga förstavalet i ett tidigt skede.
        </p>
        <p className="mb-3">
          Genom avancerad målgruppsanalys riktar vi kampanjerna mot rätt demografi, geografiskt område och beteendemönster. Varje investerad krona går mot relevanta mottagare, inte bred och odefinierad räckvidd.
        </p>
        <p>
          Resultatet är ett kontinuerligt inflöde av intresserade fastighetsägare som aktivt visar intresse för att sälja sin bostad.
        </p>
      </>
    ),
  },
  {
    id: "unique-approach",
    title: "Vad gör våra annonser unika?",
    content: (
      <>
        <p className="mb-3">
          Vi producerar inte generisk varumärkesreklam som enbart syftar till synlighet. Varje annons är konstruerad med ett tydligt konverteringsmål: att <strong>generera konkreta handlingar</strong>. Genom beprövade CTA-strukturer uppmanar vi potentiella säljare att lämna sina uppgifter, vilket skapar kvalificerade leads som vårt team sedan bearbetar vidare.
        </p>
        <p className="mb-3">
          Vi optimerar löpande budskap, bildmaterial och annonsformat för att maximera konverteringsgraden i varje enskilt område. Det är en aktiv process där kampanjen kontinuerligt förfinas baserat på verklig data.
        </p>
        <p>
          Skillnaden är tydlig: istället för att betala för passiva visningar får du kvalificerade kontakter som leder till faktiska affärsmöjligheter.
        </p>
      </>
    ),
  },
  {
    id: "results-based",
    title: "Hur fungerar resultatbaserad prissättning?",
    content: (
      <>
        <p className="mb-3">
          Vår modell innebär att vi <strong>enbart tjänar per kvalificerat möte</strong> som bokas in. Det finns ingen fast månadsavgift, inga uppsägningsvillkor och ingen bindningstid. Levererar vi inte resultat har vi heller ingen intäkt.
        </p>
        <p className="mb-3">
          Det innebär att vårt intresse är helt sammanflätat med ditt. Vi har maximalt incitament att säkerställa högsta möjliga kvalitet på varje lead och varje möte vi levererar.
        </p>
        <p>
          Det är ett partnerskap byggt på gemensamma resultat där vi alltid arbetar för att leverera konkret värde.
        </p>
      </>
    ),
  },
];

const ReadMore = () => (
  <section id="read-more" className="py-24">
    <div className="container mx-auto px-4">
      <div className="max-w-3xl mx-auto bg-card rounded-3xl p-10 md:p-14 shadow-card border border-white/10">
        <div className="text-center mb-12">
          <p className="text-sm font-semibold tracking-widest text-primary uppercase mb-3">
            Läs mer
          </p>
          <h2 className="text-3xl md:text-4xl font-serif text-foreground mb-4">
            Vanliga frågor om <span className="text-gradient">vår tjänst</span>
          </h2>
          <p className="text-muted-foreground">
            Klicka på en fråga nedan för att läsa mer om hur vi arbetar och varför det fungerar.
          </p>
        </div>

        <Accordion type="single" collapsible className="space-y-4">
          {sections.map((s) => (
            <AccordionItem
              key={s.id}
              value={s.id}
              className="border border-border rounded-2xl px-6 bg-background/50 shadow-card data-[state=open]:shadow-soft transition-shadow"
            >
              <AccordionTrigger className="text-left font-serif text-lg hover:no-underline py-5">
                {s.title}
              </AccordionTrigger>
              <AccordionContent className="text-sm text-muted-foreground leading-relaxed pb-6">
                {s.content}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="text-center mt-12">
          <button
            onClick={() => document.getElementById("book")?.scrollIntoView({ behavior: "smooth" })}
            className="hero-gradient text-primary-foreground font-semibold px-8 py-4 rounded-lg text-lg shadow-soft hover:opacity-90 transition-opacity"
          >
            Boka ett samtal — det kostar inget →
          </button>
        </div>
      </div>
    </div>
  </section>
);

export default ReadMore;
