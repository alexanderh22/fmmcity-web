import { useState, useRef, useEffect, useCallback } from "react";
import { MessageCircle, X, Send, Mail } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { supabase } from "@/integrations/supabase/client";

type Msg = { role: "user" | "assistant"; content: string };

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`;

const WELCOME: Msg = {
  role: "assistant",
  content:
    "Hej! 👋 Jag heter Christoffer och hjälper dig gärna med frågor om hur FMM City ger mäklare fler kvalificerade möten — eller boka ett samtal direkt!",
};

const EMAIL_KEYWORDS = ["e-post", "e-mail", "email", "mailadress", "mejl", "återkommer"];

function lastAssistantAsksEmail(messages: Msg[]): boolean {
  for (let i = messages.length - 1; i >= 0; i--) {
    if (messages[i].role === "assistant" && messages[i] !== WELCOME) {
      const lower = messages[i].content.toLowerCase();
      return EMAIL_KEYWORDS.some((kw) => lower.includes(kw));
    }
    if (messages[i].role === "user") return false;
  }
  return false;
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

const ChatWidget = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([WELCOME]);
  const [input, setInput] = useState("");
  const [emailInput, setEmailInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const [tooltipDismissed, setTooltipDismissed] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const emailRef = useRef<HTMLInputElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Only scroll once when a new user message is sent (to show it + start of reply)
  const scrollToUserMsg = useCallback(() => {
    if (!scrollContainerRef.current) return;
    const container = scrollContainerRef.current;
    // Scroll to bottom minus some offset to keep user msg visible
    container.scrollTo({ top: container.scrollHeight, behavior: "smooth" });
  }, []);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  // Auto-popup after 6 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setOpen((prev) => {
        if (!prev) return true;
        return prev;
      });
    }, 10000);
    return () => clearTimeout(timer);
  }, []);

  // Focus email input when it appears
  const showEmailBubble = !emailSent && !loading && lastAssistantAsksEmail(messages);

  const saveEmail = async () => {
    const email = emailInput.trim();
    if (!isValidEmail(email)) return;

    // Build context from last few messages
    const recentMessages = messages.slice(-4).map((m) => `${m.role}: ${m.content}`).join("\n");

    try {
      await supabase.from("chat_leads").insert({
        email,
        conversation_context: recentMessages,
      });
    } catch {
      // silent fail
    }

    setEmailSent(true);
    setEmailInput("");
    setMessages((prev) => [
      ...prev,
      { role: "user", content: email },
      { role: "assistant", content: `Tack! Vi återkommer till dig på **${email}** så snart som möjligt. 📩` },
    ]);
  };

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;

    const userMsg: Msg = { role: "user", content: text };
    const history = [...messages.filter((m) => m !== WELCOME), userMsg];
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);
    setEmailSent(false);

    let assistantSoFar = "";

    try {
      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ messages: history }),
      });

      if (!resp.ok || !resp.body) {
        throw new Error("Kunde inte nå AI-tjänsten");
      }

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";

      const upsert = (chunk: string) => {
        assistantSoFar += chunk;
        const snap = assistantSoFar;
        setMessages((prev) => {
          const last = prev[prev.length - 1];
          if (last?.role === "assistant" && last !== WELCOME) {
            return prev.map((m, i) => (i === prev.length - 1 ? { ...m, content: snap } : m));
          }
          return [...prev, { role: "assistant", content: snap }];
        });
      };

      // eslint-disable-next-line no-constant-condition
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });

        let idx: number;
        while ((idx = buf.indexOf("\n")) !== -1) {
          let line = buf.slice(0, idx);
          buf = buf.slice(idx + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (!line.startsWith("data: ")) continue;
          const json = line.slice(6).trim();
          if (json === "[DONE]") break;
          try {
            const parsed = JSON.parse(json);
            const c = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (c) upsert(c);
          } catch {
            buf = line + "\n" + buf;
            break;
          }
        }
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Tyvärr kunde jag inte svara just nu. Försök igen om en stund!" },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating button + tooltip */}
      {!open && (
        <div className="fixed bottom-6 right-6 z-50 flex items-end gap-3">
          {!tooltipDismissed && (
            <div className="bg-card border border-primary/20 shadow-card rounded-xl rounded-br-sm px-4 py-2.5 max-w-[180px] animate-fade-in">
              <p className="text-foreground text-sm font-medium">Har du frågor? 💬</p>
              <p className="text-muted-foreground text-xs mt-0.5">Fråga vår AI-assistent</p>
            </div>
          )}
          <button
            onClick={() => { setOpen(true); setTooltipDismissed(true); }}
            className="w-14 h-14 rounded-full hero-gradient shadow-soft flex items-center justify-center text-primary-foreground hover:opacity-90 transition-opacity flex-shrink-0"
            aria-label="Öppna chatt"
          >
            <MessageCircle className="w-6 h-6" />
          </button>
        </div>
      )}

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-6 right-6 z-50 w-[360px] max-w-[calc(100vw-2rem)] h-[520px] max-h-[calc(100vh-4rem)] bg-card border border-primary/20 rounded-2xl shadow-card flex flex-col overflow-hidden">
          {/* Header */}
          <div className="hero-gradient px-5 py-4 flex items-center justify-between rounded-t-2xl">
            <div>
              <p className="font-serif text-primary-foreground text-sm font-semibold">Christoffer</p>
              <p className="text-primary-foreground/70 text-xs">AI-assistent · FMM City</p>
            </div>
            <button onClick={() => setOpen(false)} className="text-primary-foreground/80 hover:text-primary-foreground" aria-label="Stäng chatt">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollContainerRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                    m.role === "user"
                      ? "hero-gradient text-primary-foreground rounded-br-md"
                      : "bg-background/60 text-foreground border border-white/10 rounded-bl-md"
                  }`}
                >
                  {m.role === "assistant" ? (
                    <div className="prose prose-sm prose-invert max-w-none [&>p]:mb-1.5 [&>p:last-child]:mb-0">
                      <ReactMarkdown>{m.content}</ReactMarkdown>
                    </div>
                  ) : (
                    m.content
                  )}
                </div>
              </div>
            ))}

            {/* Email input bubble */}
            {showEmailBubble && (
              <div className="flex justify-start animate-fade-in">
                <div className="max-w-[85%] rounded-2xl px-4 py-3 bg-primary/10 border border-primary/20 rounded-bl-md">
                  <p className="text-xs text-muted-foreground mb-1">För att bli kontaktad</p>
                  <div className="flex items-center gap-2 mb-2">
                    <Mail className="w-4 h-4 text-primary" />
                    <span className="text-xs font-medium text-foreground">Lämna din e-postadress</span>
                  </div>
                  <form
                    onSubmit={(e) => { e.preventDefault(); saveEmail(); }}
                    className="flex gap-2"
                  >
                    <input
                      ref={emailRef}
                      type="email"
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      placeholder="namn@exempel.se"
                      className="flex-1 bg-background/80 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                    <button
                      type="submit"
                      disabled={!isValidEmail(emailInput.trim())}
                      className="hero-gradient text-primary-foreground rounded-lg px-3 py-1.5 disabled:opacity-40 hover:opacity-90 transition-opacity text-xs font-medium"
                    >
                      Skicka
                    </button>
                  </form>
                </div>
              </div>
            )}

            {/* Bouncing dots while loading/streaming */}
            {loading && (
              <div className="flex justify-start animate-fade-in">
                <div className="bg-background/60 border border-white/10 rounded-2xl rounded-bl-md px-4 py-3 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-muted-foreground/70 animate-[bounce_1.2s_ease-in-out_infinite_0ms]" />
                  <span className="w-2 h-2 rounded-full bg-muted-foreground/70 animate-[bounce_1.2s_ease-in-out_infinite_200ms]" />
                  <span className="w-2 h-2 rounded-full bg-muted-foreground/70 animate-[bounce_1.2s_ease-in-out_infinite_400ms]" />
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          {/* Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send();
            }}
            className="px-4 py-3 border-t border-white/10 flex gap-2"
          >
            <input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Skriv ett meddelande..."
              className="flex-1 bg-background/60 border border-white/10 rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              disabled={loading}
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="hero-gradient text-primary-foreground rounded-lg px-3 py-2 disabled:opacity-40 hover:opacity-90 transition-opacity"
              aria-label="Skicka"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};

function assistantStarted(msgs: Msg[]) {
  const last = msgs[msgs.length - 1];
  return last?.role === "assistant" && msgs.length > 1;
}

export default ChatWidget;
