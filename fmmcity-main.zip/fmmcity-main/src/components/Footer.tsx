import logoSimple from "@/assets/logo-simple.png";

const Footer = () => (
  <footer className="bg-foreground py-12">
    <div className="container mx-auto px-4">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-2">
          <img src={logoSimple} alt="FMM City" className="h-6 brightness-200" />
          <span className="font-serif text-lg text-primary-foreground">FMM City</span>
        </div>
        <p className="text-sm text-muted-foreground/80">
          © {new Date().getFullYear()} FMM City. Alla rättigheter förbehållna.
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;
