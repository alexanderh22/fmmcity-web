import { useState } from "react";
import { z } from "zod";

const schema = z.object({
  firstName: z.string().trim().min(1, "Förnamn krävs").max(100),
  lastName: z.string().trim().min(1, "Efternamn krävs").max(100),
  phone: z.string().trim().min(1, "Telefonnummer krävs").max(20),
  email: z.string().trim().email("Ogiltig e-postadress").max(255),
  office: z.string().trim().min(1, "Kontor krävs").max(100),
  type: z.enum(["konsult", "kontor"], { required_error: "Välj typ" }),
});

type FormData = z.infer<typeof schema>;

const CALENDLY_URL = "https://calendly.com/fmmcity";

const BookingForm = () => {
  const [form, setForm] = useState<Partial<FormData>>({ type: "konsult" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = schema.safeParse(form);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.issues.forEach((issue) => {
        fieldErrors[issue.path[0] as string] = issue.message;
      });
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setSubmitted(true);
    const params = new URLSearchParams({
      name: `${result.data.firstName} ${result.data.lastName}`,
      email: result.data.email,
    });
    window.open(`${CALENDLY_URL}?${params.toString()}`, "_blank");
  };

  const update = (key: keyof FormData, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: "" }));
  };

  const inputClasses = "w-full px-4 py-3 rounded-lg border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-shadow";

  if (submitted) {
    return (
      <section id="book" className="py-24">
        <div className="container mx-auto px-4 max-w-lg text-center">
          <div className="bg-card rounded-2xl p-10 shadow-card border border-white/10">
            <div className="w-16 h-16 rounded-full hero-gradient flex items-center justify-center mx-auto mb-6">
              <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary-foreground"><path d="M20 6 9 17l-5-5" /></svg>
            </div>
            <h2 className="text-2xl font-serif text-foreground mb-3">Tack!</h2>
            <p className="text-muted-foreground mb-6">Välj en tid som passar dig i Calendly-fönstret. Vi ser fram emot att prata med dig!</p>
            <button onClick={() => setSubmitted(false)} className="text-sm text-primary hover:underline">Boka ett till möte</button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="book" className="py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-lg mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-serif text-white mb-4">Boka ett samtal</h2>
            <p className="text-white/70">Fyll i dina uppgifter så bokar vi in ett kort samtal för att diskutera hur vi kan hjälpa dig.</p>
          </div>

          <form onSubmit={handleSubmit} className="bg-card rounded-2xl p-8 shadow-card border border-white/10 space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Förnamn</label>
                <input className={inputClasses} placeholder="Förnamn" value={form.firstName || ""} onChange={(e) => update("firstName", e.target.value)} />
                {errors.firstName && <p className="text-destructive text-xs mt-1">{errors.firstName}</p>}
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Efternamn</label>
                <input className={inputClasses} placeholder="Efternamn" value={form.lastName || ""} onChange={(e) => update("lastName", e.target.value)} />
                {errors.lastName && <p className="text-destructive text-xs mt-1">{errors.lastName}</p>}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Telefonnummer</label>
              <input className={inputClasses} placeholder="070-123 45 67" value={form.phone || ""} onChange={(e) => update("phone", e.target.value)} />
              {errors.phone && <p className="text-destructive text-xs mt-1">{errors.phone}</p>}
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">E-postadress</label>
              <input className={inputClasses} placeholder="din@epost.se" type="email" value={form.email || ""} onChange={(e) => update("email", e.target.value)} />
              {errors.email && <p className="text-destructive text-xs mt-1">{errors.email}</p>}
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Kontor / byrå</label>
              <input className={inputClasses} placeholder="Namn på ditt kontor" value={form.office || ""} onChange={(e) => update("office", e.target.value)} />
              {errors.office && <p className="text-destructive text-xs mt-1">{errors.office}</p>}
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Typ</label>
              <div className="flex gap-4">
                {(["konsult", "kontor"] as const).map((t) => (
                  <button
                    type="button"
                    key={t}
                    onClick={() => update("type", t)}
                    className={`flex-1 py-3 rounded-lg border text-sm font-medium transition-colors ${
                      form.type === t
                        ? "hero-gradient text-primary-foreground border-transparent"
                        : "bg-background text-foreground border-input hover:bg-secondary"
                    }`}
                  >
                    {t === "konsult" ? "Konsult" : "Mäklarkontor"}
                  </button>
                ))}
              </div>
              {errors.type && <p className="text-destructive text-xs mt-1">{errors.type}</p>}
            </div>

            <button type="submit" className="w-full hero-gradient text-primary-foreground font-semibold py-4 rounded-lg text-lg shadow-soft hover:opacity-90 transition-opacity">
              Boka samtal →
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default BookingForm;
