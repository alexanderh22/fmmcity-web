import logoFull from "@/assets/logo-full.png";

const Hero = () => {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center pt-24">
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="relative mx-auto mb-8 w-fit animate-fade-in-up">
            <div className="absolute inset-0 bg-background/20 blur-2xl rounded-full scale-125" />
            <img src={logoFull} alt="FMM City" className="relative h-28 rounded-xl" />
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif text-white mb-6 animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
            Digital annonsering som levererar <span className="text-gradient-light">bokade möten</span>
          </h1>
          <p className="text-lg md:text-xl text-white/80 mb-4 max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            Vi driver resultatbaserad annonsering via Meta för fastighetsmäklare — och förvandlar det till 10 till 20 kvalificerade, exklusiva möten per månad.
          </p>
          <p className="text-base text-white/60 mb-10 max-w-xl mx-auto animate-fade-in-up" style={{ animationDelay: "0.25s" }}>
            En mäklare per område. Vi tjänar enbart per kvalificerat möte vi levererar.
          </p>

          {/* Trust badges */}
          <div className="flex flex-wrap justify-center gap-6 mb-10 animate-fade-in-up" style={{ animationDelay: "0.3s" }}>
            {[
              { value: "40–90", label: "leads per månad" },
              { value: "10–20", label: "kvalificerade möten" },
              { value: "100%", label: "resultatbaserat" },
            ].map((stat) => (
              <div key={stat.label} className="bg-white/30 border border-white/40 rounded-xl px-6 py-3">
                <div className="text-xl font-serif text-gradient-light">{stat.value}</div>
                <div className="text-xs text-white/70">{stat.label}</div>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up" style={{ animationDelay: "0.35s" }}>
            <button
              onClick={() => scrollTo("book")}
              className="hero-gradient text-primary-foreground font-semibold px-8 py-4 rounded-lg text-lg shadow-soft hover:opacity-90 transition-opacity"
            >
              Boka ett samtal
            </button>
            <button
              onClick={() => scrollTo("process")}
              className="bg-white/10 text-white font-semibold px-8 py-4 rounded-lg text-lg border border-white/20 hover:bg-white/20 transition-colors"
            >
              Se hur det fungerar
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
