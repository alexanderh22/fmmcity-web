import { CheckCircle, TrendingUp, Shield, Zap } from "lucide-react";

const highlights = [
  {
    icon: TrendingUp,
    title: "Stärk ditt varumärke",
    description: "Vår annonsering positionerar dig som den ledande mäklaren i ditt område. Du syns där potentiella säljare scrollar.",
  },
  {
    icon: Shield,
    title: "Exklusivt per område",
    description: "Vi arbetar med en mäklare per område. Alla leads och möten är exklusivt dina — inga delade kontakter.",
  },
  {
    icon: Zap,
    title: "100% resultatbaserat",
    description: "Vi tjänar enbart per kvalificerat möte vi levererar. Ingen bindningstid, inga fasta avgifter.",
  },
];

const benefits = [
  "10 till 20 kvalificerade möten per månad",
  "40 till 90 leads genererade via Meta-annonsering",
  "Professionella innesäljare som kvalificerar varje lead",
  "Resultatbaserad annonsering som stärker din närvaro",
  "Inga delade leads — allt är exklusivt ditt",
  "Ingen bindningstid eller fasta kostnader",
];

const Benefits = () => (
  <section id="benefits" className="py-24">
    <div className="container mx-auto px-4">
      {/* Highlight cards */}
      <div className="text-center mb-16">
        <p className="text-sm font-semibold tracking-widest text-primary uppercase mb-3">Fördelar</p>
        <h2 className="text-3xl md:text-4xl font-serif text-white mb-4">
          Varför mäklare väljer <span className="text-gradient-light">FMM City</span>
        </h2>
      </div>

      <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-20">
        {highlights.map((h, i) => (
          <div key={i} className="bg-card rounded-2xl p-8 border border-white/10 shadow-card hover:shadow-soft transition-shadow">
            <div className="w-12 h-12 rounded-xl hero-gradient flex items-center justify-center mb-5">
              <h.icon className="w-6 h-6 text-primary-foreground" />
            </div>
            <h3 className="font-serif text-lg text-foreground mb-2">{h.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{h.description}</p>
          </div>
        ))}
      </div>

      {/* Stats + checklist */}
      <div className="max-w-4xl mx-auto bg-card rounded-3xl p-10 md:p-14 shadow-card border border-white/10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-2xl font-serif text-foreground mb-6">Allt du behöver för fler uppdrag</h3>
            <ul className="space-y-4">
              {benefits.map((b, i) => (
                <li key={i} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                  <span className="text-foreground">{b}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-background/50 rounded-2xl p-8">
            <div className="text-center space-y-6">
              <div>
                <div className="text-5xl font-serif text-gradient">40–90</div>
                <p className="text-muted-foreground text-sm">leads via Meta per månad</p>
              </div>
              <div className="h-px bg-border" />
              <div>
                <div className="text-5xl font-serif text-gradient">10–20</div>
                <p className="text-muted-foreground text-sm">kvalificerade möten per månad</p>
              </div>
              <div className="h-px bg-border" />
              <div>
                <div className="text-3xl font-serif text-foreground">1</div>
                <p className="text-muted-foreground text-sm">mäklare per område</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default Benefits;
